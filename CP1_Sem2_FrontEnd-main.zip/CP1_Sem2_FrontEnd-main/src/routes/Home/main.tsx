export default function Home() {
  return (
    <main className="home">
      <div>
        <h1>Bem-vindo à Página Inicial da Smartphone Store!</h1>
        <p>Veja nossos produtos!</p>
      </div>
    </main> 
  );
}