import { Link } from "react-router-dom";
export default function Aparelhos() {
    return (
        <main>
        <h1>Página de Aparelhos</h1>
          <Link to="/Aparelhos/novo">Adicionar Novo Aparelho</Link>
        </main>




    )
}
