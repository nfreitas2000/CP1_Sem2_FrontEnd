export default function VisualizarAparelho(){

    return(
        <main>
            <h1>Visualizar Aparelho</h1>
        </main>
    )
}