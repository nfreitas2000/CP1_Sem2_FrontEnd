import { Link } from "react-router-dom";
export default function Error(){

    return(
        <main>
            <h1>ERROR 404!</h1>
            <p>Desculpe, a página que você está procurando não existe!</p>
             <Link className="erro" to="/">Voltar para a Home</Link>
        </main>
    )

}