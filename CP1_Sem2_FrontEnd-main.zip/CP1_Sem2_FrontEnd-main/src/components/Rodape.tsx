export default function Rodape(){
    return(
        <footer>
            <p>Rodapé - Av. Paulista, 610 - São Paulo, SP</p>
        </footer>
    )
}