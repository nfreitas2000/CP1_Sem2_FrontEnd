import iphone from "./image/iphone-16.png"
import samsung from "./image/samsung-galaxy-a26.png"
import tabletandroid from "./image/tablet-android-x-513.png"
import tabletxiaomi from "./image/tabletxiaomi.png"
import smartwatch from "./image/smartwatch-xiaomi-0022.png"


export const listaAparelhos = [
    {
        id:1,
        nome:"Celular Samsung Galaxy A26",
        preco:4.999,
        img: {samsung}
    },
    {
        id:2,
        nome:"Smartphone Iphone Pro max 9000",
        preco:16.799,
        img: {iphone}
    },
    {
        id:3,
        nome:"Tablet Android X-513",
        preco:2.499,
        img: {tabletandroid}
    },
    {
        id:4,
        nome:"Tablet Xiaomi Redmi",
        preco:1.978,
        img: {tabletxiaomi}
    },
    {
        id:5,
        nome:"Smartwatch Xiaomi 0022",
        preco:600,
        img: {smartwatch}
    }
]