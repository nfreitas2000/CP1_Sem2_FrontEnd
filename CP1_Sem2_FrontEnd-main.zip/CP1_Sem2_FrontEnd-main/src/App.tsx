import { Outlet } from "react-router-dom";
import Menu from "./components/Menu";
import Rodape from "./components/Rodape";

export default function App() {
  return (
    <>
      <div className="app">
        <Menu />
        <Outlet />
        <Rodape />
      </div>
    </>
  );
}

